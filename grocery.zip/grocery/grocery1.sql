-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 12, 2020 at 09:48 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `grocery`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cart_id` int(11) NOT NULL,
  `cid` int(10) NOT NULL,
  `pid` int(10) NOT NULL,
  `no_of_items` int(10) NOT NULL,
  `cost_of_item` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Triggers `cart`
--
DELIMITER $$
CREATE TRIGGER `delete` BEFORE DELETE ON `cart` FOR EACH ROW BEGIN
	insert into purchase(pcid,ppid,no_of_items,cost_of_items,date_time) VALUES(old.cid,old.pid,old.no_of_items,old.no_of_items*old.cost_of_item,now());
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `insert1` AFTER INSERT ON `cart` FOR EACH ROW BEGIN
	update products set no_of_items=no_of_items-1 where ID=new.pid; 
    
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `update1` AFTER UPDATE ON `cart` FOR EACH ROW BEGIN
	update products set no_of_items=no_of_items-1 where ID=old.pid;
end
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `ID` int(10) NOT NULL,
  `user` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `phone_no` bigint(10) NOT NULL,
  `Time_of_join` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`ID`, `user`, `password`, `phone_no`, `Time_of_join`) VALUES
(1, 'Dharani', 'Ds', 1234567890, '2018-02-28 09:39:37'),
(2, 'DS', 'Dharani', 9876543211, '2018-02-28 03:24:12'),
(3, 'qwerty', 'qwerty', 9876543212, '2018-02-28 02:56:59'),
(4, 'qwerty123', 'uyfkl', 76, '2018-02-28 02:09:40'),
(6, 'wertyu', '123', 9876543210, '2018-02-28 16:14:15');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `e_username` varchar(20) NOT NULL,
  `e_password` varchar(20) NOT NULL,
  `e_phone_no` bigint(10) NOT NULL,
  `e_date_join` datetime NOT NULL,
  `eid` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`e_username`, `e_password`, `e_phone_no`, `e_date_join`, `eid`) VALUES
('priya', 'p', 868686867, '2020-09-12 11:08:44', 1),
('suyash ', 'sg', 7878787640, '2020-09-12 11:11:40', 2);

-- --------------------------------------------------------

--
-- Table structure for table `image`
--

CREATE TABLE `image` (
  `img` longblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `ID` int(10) NOT NULL,
  `catogery` varchar(20) NOT NULL,
  `Item_name` varchar(20) NOT NULL,
  `cost` int(10) NOT NULL,
  `no_of_items` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`ID`, `catogery`, `Item_name`, `cost`, `no_of_items`) VALUES
(1, 'Households', 'Air Freshener', 90, 25),
(2, 'Kitchen', 'peanut', 120, 87),
(3, 'kitchen', 'ghee', 110, 48),
(4, 'oil', 'gemini', 120, 86),
(13, 'kitchen', 'sabudana', 40, 9);

-- --------------------------------------------------------

--
-- Table structure for table `purchase`
--

CREATE TABLE `purchase` (
  `pcid` int(10) NOT NULL,
  `ppid` int(10) NOT NULL,
  `no_of_items` int(10) NOT NULL,
  `cost_of_items` int(10) NOT NULL,
  `date_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchase`
--

INSERT INTO `purchase` (`pcid`, `ppid`, `no_of_items`, `cost_of_items`, `date_time`) VALUES
(1, 1, 2, 180, '2020-09-11 22:18:23'),
(1, 1, 2, 180, '2020-09-11 22:34:50'),
(1, 2, 1, 9, '2020-09-11 22:34:50'),
(1, 1, 1, 90, '2020-09-11 22:42:42'),
(1, 1, 1, 90, '2020-09-11 22:45:26'),
(1, 1, 1, 90, '2020-09-11 22:48:47'),
(1, 2, 2, 18, '2020-09-11 22:48:51'),
(1, 1, 8, 720, '2020-09-12 10:50:40'),
(3, 2, 21, 1050, '2020-09-12 10:50:40'),
(1, 1, 1, 90, '2020-09-12 13:06:19'),
(1, 4, 1, 120, '2020-09-12 13:07:48');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cart_id`),
  ADD KEY `fk_references_cart_customer` (`cid`),
  ADD KEY `pid` (`pid`) USING BTREE;

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `ID` (`ID`),
  ADD UNIQUE KEY `user` (`user`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`eid`),
  ADD UNIQUE KEY `e_username` (`e_username`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `Item_name` (`Item_name`);

--
-- Indexes for table `purchase`
--
ALTER TABLE `purchase`
  ADD KEY `fk_references_purchase_customer` (`pcid`),
  ADD KEY `fk_references_purchase_products` (`ppid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `eid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `fk_references_cart_customer` FOREIGN KEY (`cid`) REFERENCES `customer` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_references_cart_products` FOREIGN KEY (`pid`) REFERENCES `products` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `purchase`
--
ALTER TABLE `purchase`
  ADD CONSTRAINT `fk_references_purchase_customer` FOREIGN KEY (`pcid`) REFERENCES `customer` (`ID`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_references_purchase_products` FOREIGN KEY (`ppid`) REFERENCES `products` (`ID`) ON DELETE NO ACTION ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
